This Google Android Emulator was developed by Google Android Developers and not me, I just put the whole emualtor together, that is i got all the files of the emualtor and configured it, so it'll be easy for you to run by just clicking the *.exe files :)

Have Fun!!
Xda2_Haseeb @ XDA-Devs
(http://forum.xda-developers.com/showthread.php?p=4420071#post4420071)