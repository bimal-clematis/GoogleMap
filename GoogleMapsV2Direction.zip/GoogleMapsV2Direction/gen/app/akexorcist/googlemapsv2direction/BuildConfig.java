/** Automatically generated file. DO NOT MODIFY */
package app.akexorcist.googlemapsv2direction;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}