package com.utkarsh.nearme;




import android.app.ProgressDialog;
import android.content.Context;

public class MyProgressDialog extends ProgressDialog {

    public MyProgressDialog(Context context) {
        super(context,R.style.NewDialog);

        // TODO Auto-generated constructor stub
    }

}